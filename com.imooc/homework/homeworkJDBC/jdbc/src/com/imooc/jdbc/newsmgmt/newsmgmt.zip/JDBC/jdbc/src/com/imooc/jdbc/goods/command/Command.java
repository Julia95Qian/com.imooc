package com.imooc.jdbc.goods.command;

public interface Command {
    public void excute();
}
