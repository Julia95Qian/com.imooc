package com.imooc.jdbc.hrapp.command;

public interface Command {
    public void execute();
}
