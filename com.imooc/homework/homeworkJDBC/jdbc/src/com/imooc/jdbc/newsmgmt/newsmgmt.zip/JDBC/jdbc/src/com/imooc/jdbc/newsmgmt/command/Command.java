package com.imooc.jdbc.newsmgmt.command;

public interface Command {

    public void execute();
}
